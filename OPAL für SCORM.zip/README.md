![logo_opal](https://www.google.com/url?sa=i&url=https%3A%2F%2Fbildungsportal.sachsen.de%2Fopal%2Fraw%2F20220208%2Fthemes%2Fbasic_new%2Fimages%2Fgeneral%2F&psig=AOvVaw3u7as2JrHZ5753agYLfyaP&ust=1741426656489000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCNDgg_zV94sDFQAAAAAdAAAAABAE)

# Agenda

Lernmanagementsystem OPAL



* Vorhandenes nutzen
* Neues erstellen und gestalten
* Kurs(e)
* Bausteine
* Lerngruppe(n)
* Weiterführende Angebote und Material kennenlernen


# Ziele der Veranstaltung

* Sie haben einen Überblick über die Struktur von OPAL und die Möglichkeiten sowie Funktionalitäten, die es bieten kann.
* Sie legen selbst Kurse an.
* Sie konfigurieren Kursbausteine.
* Sie organisieren Ihre Gruppen.
* Sie haben viele weitergehende Fragen....


# OPAL: Funktionen und Rollen

__Online Plattform für Akademisches Lehren und Lernen an den sächsischen Hochschulen __


Was kann man damit machen?

Im Rahmen von Kursen kann man via OPAL

* Materialien/Informationen bereitstellen
* Gruppen, Teilnehmende, Termine etc. organisieren
* mit anderen zusammenarbeiten
* testen und prüfen

__Wer kann damit arbeiten?__

* Lehrende „Autoren“, „Verantwortliche“ der Lernressource
* Studierende „Registrierte Benutzer“
* Externe mit IDM-Zugang von URZ
* Externe „Externe Selbstregistrierer“


# Bereiche in OPAL
* Einstellungen
* Startseite
* Lehren und Lernen
* Kursangebote/Katalog




